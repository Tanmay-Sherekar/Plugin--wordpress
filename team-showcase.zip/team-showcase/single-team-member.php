<?php get_header(); ?>

<main class="team-single">
<?php while (have_posts()) : the_post(); 
    $role = get_post_meta(get_the_ID(), '_ts_role', true);
?>
    <article>
        <h1><?php the_title(); ?></h1>
        <p class="role"><?php echo esc_html($role); ?></p>

        <?php the_post_thumbnail('large'); ?>

        <div class="bio">
            <div class="bio-content collapsed">
                <?php the_content(); ?>
            </div>
            <button id="toggleBio">Read More</button>
        </div>
    </article>
<?php endwhile; ?>
</main>

<script>
document.getElementById('toggleBio').addEventListener('click', function(){
    const bio = document.querySelector('.bio-content');
    bio.classList.toggle('collapsed');
    this.innerText = bio.classList.contains('collapsed') ? 'Read More' : 'Read Less';
});
</script>

<style>
.bio-content.collapsed {
    max-height: 120px;
    overflow: hidden;
}
</style>

<?php get_footer(); ?>
