<?php
/**
 * Plugin Name: Team Showcase
 * Description: Custom Team Showcase with CPT, Shortcode & REST API
 * Version: 1.0
 * Author: Tanmay Sherekar
 */

if (!defined('ABSPATH')) exit;

/*----------------------------------
 Register Custom Post Type
-----------------------------------*/
function ts_register_team_member_cpt() {
    register_post_type('team_member', [
        'labels' => [
            'name' => 'Team Members',
            'singular_name' => 'Team Member'
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-groups',
        'supports' => ['title', 'editor', 'thumbnail'],
        'rewrite' => ['slug' => 'team']
    ]);
}
add_action('init', 'ts_register_team_member_cpt');

/*----------------------------------
 Meta Box
-----------------------------------*/
function ts_add_meta_boxes() {
    add_meta_box(
        'ts_team_details',
        'Team Member Details',
        'ts_meta_box_callback',
        'team_member',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'ts_add_meta_boxes');

function ts_meta_box_callback($post) {
    wp_nonce_field('ts_save_meta', 'ts_meta_nonce');

    $role = get_post_meta($post->ID, '_ts_role', true);
    $short_bio = get_post_meta($post->ID, '_ts_short_bio', true);
    ?>
    <p>
        <label>Role</label><br>
        <input type="text" name="ts_role" value="<?php echo esc_attr($role); ?>" style="width:100%;">
    </p>
    <p>
        <label>Short Bio</label><br>
        <textarea name="ts_short_bio" rows="4" style="width:100%;"><?php echo esc_textarea($short_bio); ?></textarea>
    </p>
    <?php
}

/*----------------------------------
 Save Meta Fields
-----------------------------------*/
function ts_save_meta($post_id) {
    if (!isset($_POST['ts_meta_nonce']) || !wp_verify_nonce($_POST['ts_meta_nonce'], 'ts_save_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    if (isset($_POST['ts_role'])) {
        update_post_meta($post_id, '_ts_role', sanitize_text_field($_POST['ts_role']));
    }

    if (isset($_POST['ts_short_bio'])) {
        update_post_meta($post_id, '_ts_short_bio', sanitize_textarea_field($_POST['ts_short_bio']));
    }
}
add_action('save_post', 'ts_save_meta');

/*----------------------------------
 Shortcode [team_showcase]
-----------------------------------*/
function ts_team_showcase_shortcode() {

    $role_filter = isset($_GET['role']) ? sanitize_text_field($_GET['role']) : '';

    $args = [
        'post_type' => 'team_member',
        'posts_per_page' => -1,
        'post_status' => 'publish',
    ];

    if ($role_filter) {
        $args['meta_query'] = [
            [
                'key' => '_ts_role',
                'value' => $role_filter,
                'compare' => '='
            ]
        ];
    }

    $query = new WP_Query($args);
    ob_start();

    echo '<div class="ts-grid">';

    while ($query->have_posts()) {
        $query->the_post();
        $role = get_post_meta(get_the_ID(), '_ts_role', true);
        $short_bio = get_post_meta(get_the_ID(), '_ts_short_bio', true);
        ?>
        <div class="ts-card">
            <?php the_post_thumbnail('medium'); ?>
            <h3><?php the_title(); ?></h3>
            <p class="role"><?php echo esc_html($role); ?></p>
            <p><?php echo esc_html($short_bio); ?></p>
            <a href="<?php the_permalink(); ?>">View Profile</a>
        </div>
        <?php
    }

    echo '</div>';
    wp_reset_postdata();

    return ob_get_clean();
}
add_shortcode('team_showcase', 'ts_team_showcase_shortcode');

/*----------------------------------
 Assets
-----------------------------------*/
function ts_assets() {
    wp_enqueue_style('ts-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
}
add_action('wp_enqueue_scripts', 'ts_assets');

//Custom rest api

add_action('rest_api_init', function () {

    register_rest_route('2creative/v1', '/team-members', [
        'methods' => 'GET',
        'callback' => 'ts_get_team_members',
    ]);

    register_rest_route('2creative/v1', '/team-members/(?P<id>\d+)', [
        'methods' => 'GET',
        'callback' => 'ts_get_single_team_member',
    ]);
});

function ts_get_team_members() {
    $posts = get_posts([
        'post_type' => 'team_member',
        'post_status' => 'publish',
        'numberposts' => -1
    ]);

    $data = [];

    foreach ($posts as $post) {
        $data[] = [
            'id' => $post->ID,
            'name' => $post->post_title,
            'role' => get_post_meta($post->ID, '_ts_role', true),
            'short_bio' => get_post_meta($post->ID, '_ts_short_bio', true),
            'photo_url' => get_the_post_thumbnail_url($post->ID, 'medium'),
            'permalink' => get_permalink($post->ID)
        ];
    }

    return rest_ensure_response($data);
}

function ts_get_single_team_member($request) {
    $id = (int) $request['id'];
    $post = get_post($id);

    if (!$post || $post->post_type !== 'team_member') {
        return new WP_Error('not_found', 'Team member not found', ['status' => 404]);
    }

    return [
        'id' => $post->ID,
        'name' => $post->post_title,
        'role' => get_post_meta($post->ID, '_ts_role', true),
        'short_bio' => get_post_meta($post->ID, '_ts_short_bio', true),
        'photo_url' => get_the_post_thumbnail_url($post->ID, 'medium'),
        'permalink' => get_permalink($post->ID)
    ];
}
