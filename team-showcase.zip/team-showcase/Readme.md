\*\* Team Showcase Plugin

---

\*\* Setup

1. Upload plugin folder to /wp-content/plugins/
2. Activate "Team Showcase"
3. Add Team Members from admin
4. Use shortcode [team_showcase]

---

\*\*\* Shortcode

/team-page/?role=designer

---

\*\* REST API

GET /wp-json/2creative/v1/team-members
GET /wp-json/2creative/v1/team-members/12

---

\*\* Features

- Custom Post Type
- Secure Meta Fields
- Shortcode with filtering
- REST API
- Template override
- JS interaction (Read more)
